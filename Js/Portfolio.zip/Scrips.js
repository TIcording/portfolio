window.onload = function() {
    const btn = document.getElementById("category__front")

    const btn2 = document.getElementById("category__back")

    const btn3 = document.getElementById("category__AI")

    btn.addEventListener("click",clickBtn1)
    btn2.addEventListener("click",clickBtn2)
    btn3.addEventListener("click",clickBtn3)
}


function clickBtn1(){
    document.getElementById("category__front__contents").style.display="none";

}
function clickBtn2(){
    console.log("btn2")
}

function clickBtn3(){
    console.log("btn3")
}